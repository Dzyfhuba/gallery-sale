import Viewer from 'viewerjs';

const gallery = new Viewer(document.getElementById('galleries'));