$(function() {
    $('#data').DataTable().order(4, 'desc').draw();
});