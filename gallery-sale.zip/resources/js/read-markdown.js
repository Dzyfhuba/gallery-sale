import '@toast-ui/editor/dist/toastui-editor.css';
import Viewer from '@toast-ui/editor/dist/toastui-editor-viewer';

const viewer = new Viewer({
    el: document.querySelector('#show'),
    initialValue: $('#md').val(),
});
