<footer>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col">
                <span class="copyright">Copyright &copy; Alam Rohman Garden 2022</span>
            </div>
        </div>
    </div>
</footer>
