<a class="btn btn-success direct-to-us"
    href="https://api.whatsapp.com/send?phone=6282244246255&text=Halo%20gan,%20Saya%20mau%20order" role="button">
    <i class="bi bi-whatsapp"></i>
</a>
